# CGMES
Common Grid Model Exchange Standard (CGMES)

This include the issue tracking for CIM information model and profiling.
